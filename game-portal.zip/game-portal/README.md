# Game Portal

A simple collection of free browser games, ready to host on **GitHub Pages**.

## Included Games

### Five Nights at Freddy's
- FNAF 1
- FNAF 3
- FNAF 4
- FNAF 4 Halloween Edition
- Sister Location
- Ultimate Custom Night
- Pizzeria Simulator

### Five Nights at Candy's
- FNaC 1
- FNaC 2

### Minecraft (Eaglercraft)
- 1.5.2
- 1.8.8
- 1.12.2
- Alpha 1.2.6 (large file ~8MB)
- Beta 1.3 (large file ~4MB)
- Indev

### Other
- Getting Over It with Bennett Foddy
- Happy Wheels
- They Are Coming

## How to put this on GitHub Pages

1. Create a new repository on GitHub (name it whatever you want, or `yourusername.github.io` for a user site).
2. Upload **all** the files and the `games` folder from this project.
3. Go to the repository **Settings → Pages**.
4. Under **Source**, select the branch `main` (or `master`) and folder `/ (root)`.
5. Click Save.
6. After a minute your site will be live at:
   - `https://yourusername.github.io/` (if the repo is named `yourusername.github.io`)
   - or `https://yourusername.github.io/repo-name/`

## Notes

- Most games load their assets from external CDNs (jsDelivr, etc.). If a game stops loading, the external source may be offline.
- The large Minecraft Alpha / Beta / Indev files embed the game data. They work offline once loaded but make the repository bigger.
- Two Minecraft versions (1.21.4 and Beta 1.7.3) were broken in the original files and are marked as such.

## File Structure

```
/
├── index.html          ← Homepage with game list
├── README.md
└── games/
    ├── fnaf-1.html
    ├── fnaf-3.html
    ├── ...
    └── minecraft-*.html
```
